package com.example.game;

public class Database {

    Integer[] shapes={
            R.drawable.square,
            R.drawable.circle,
            R.drawable.triangle,
            R.drawable.star,
            R.drawable.hexagon

    };
    String[] answers={
            "square",
            "circle",
            "triangle",
            "star",
            "hexagon"
    };

}
