package com.example.game;

public class Shapes {

    String name;
    int image;

    public String getName() {
        return name;
    }

    public int getImage() {
        return image;
    }

    public Shapes(String name, int image){
        this.name=name;
        this.image=image;
    }
}
